import { PlantInfoData } from './plant-info-data';

describe('PlantInfoData', () => {
  it('should create an instance', () => {
    expect(new PlantInfoData()).toBeTruthy();
  });
});
