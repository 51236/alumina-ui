/**
 * Created By : Sangwin Gawande (http://sangw.in)
 */

import { Injectable, Type } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpParams } from "@angular/common/http";
import { getMaxListeners } from 'process';
import { HttpHeaders } from '@angular/common/http';
import {PlantInfoData} from 'src/app/plant-info-data';
@Injectable()
export class UserService {

	constructor(private httpclient:HttpClient) { }

	
	

	baseurl_login:string ="https://cors-anywhere.herokuapp.com/http://117.211.75.160:8080/alumini/login?userName=hindalco &password=hindalco@1232}";
	baseurl_show_list:string ="https://cors-anywhere.herokuapp.com/http://117.211.75.160:8080/alumini/show/power plant";
	baseurl_insert:string ="https://cors-anywhere.herokuapp.com/http://117.211.75.160:8080/alumini/show/";

	
	login(data) : Observable<any> {
		
		const headers= new HttpHeaders()
  .set('content-type', 'application/json')
  .set('Access-Control-Allow-Origin', 'https://cors-anywhere.herokuapp.com/http://117.211.75.160:8080/alumini/login {"userName":"hindalco","password":"hindalco@123"}')
  .set('Access-Control-Allow-Methods', 'get')
  .set('Access-Control-Allow-Headers', '*')
  .set('Access-Control-Allow-Credentials', 'true');
  
  

		let params = new HttpParams();
		params = params.append('password:', 'mrumakanta@gmail.com');
		params = params.append('username:', 'dddd');
		
		return this.httpclient.get<any>(this.baseurl_login,
		{
			'headers':headers
		});
	}

	display(data) : Observable<any> {
		
		const headers= new HttpHeaders()
  .set('content-type', 'application/json')
  .set('Access-Control-Allow-Origin', '*')
  .set('Access-Control-Allow-Methods', 'get')
  .set('Access-Control-Allow-Headers', '*')
  .set('Access-Control-Allow-Credentials', 'true');
  
  

		let params = new HttpParams();
		params = params.append('id:', '1');
		
		
		return this.httpclient.get<any>(this.baseurl_show_list,
		{
			'headers':headers
		});
	}

insert(plant:PlantInfoData): Observable<any>{

	const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(plant);
	console.log(body);
  
alert(body);
  
  return  this.httpclient.post<any>(this.baseurl_insert,body,{'headers':headers}

	
	);
		
	
	
		
		

}


	
	}

