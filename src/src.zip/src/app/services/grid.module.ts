export class DynamicGrid{     
    name:string;  
    email:string;  
    phone:string;  
}