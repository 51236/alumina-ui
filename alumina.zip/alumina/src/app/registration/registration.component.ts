import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ValidationService } from '../services/config/config.service';
import { routerTransition } from '../services/config/config.service';
import { AgGridModule } from 'ag-grid-angular';
import { UserService } from '../services/user/user.service';
import {PlantInfoData} from 'src/app/plant-info-data';
import { stringify } from '@angular/compiler/src/util';
import { HttpClient } from '@angular/common/http';
import { TooltipModule } from '@syncfusion/ej2-angular-popups';
import{CustomValidators} from  'src/app/custom-validators';


class DynamicGrid{     
      title1:string;  
    title2:string;  
    title3:string; 
}

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],
  animations: [routerTransition()],
	host: { '[@routerTransition]': ''}
})


export class RegistrationComponent implements OnInit {

  

  containers = [];
 
industry:any =[
  
    {
      "userName":"hindalco",
    "plantInfo":{
       "plantId":2,
       "password":"ttt",
       "pin":"755007",
       "plantNm":"hindolc",
       "typ":"company",
       "district":"ctc",
       "town":"ctc",
       "street":"badam badi",
       "state":"odisha",
       "email":"aa@gmail.com",
       "web":"hindolc.com",
       "zonal":"ctc",
       "grdId":"12345",
       "timeStamp":"2020-09-22",
       "authPerson":"jayashree",
       "authoPerMob":"7008480987",
       "authPersonDesig":"developer",
       "cpcbUser":"jaya",
       "cpcbUserEmail":"jaya@gmail.com",
       "cpcbUserMob":"998789876",
       "cpcbUsr2":"jatan",
       "cpcbUserEmail2":"jatan@gmail.com",
       "cpcbUserMob2":"87654321",
       "latLong":"34",
       "connected":"456",
       "deptEmail":"jatan123@gmail.com",
       "category":"power plant",
       "plantName":"yyyy",
       "analyzerCount":"123",
       "HQOEmail":"jatan345@gmail.com",
       "inletUrl":"hhtp//jatan@gmail.com",
       "outletUrl":"http//jatan345.il.com",
       "roUser":"jatan678@gmail.com",
       "roUserEmail":"jayashree234@gmail.com",
       "roUserMob":"7865432123",
       "plantSlug":"yyyy",
       "authReq":"hgtyh",
       "stationCount":"678",
       "plantVendor":"hnbjy",
       "caaqmsStation":"76543",
       "cemsStation":"6789876",
       "ceqmsStation":"6754321",
       "secdPersonDesig":"rrrrr",
       "secdPersonMob":"765432134",
       "secdEmail":"jsitam@gmail.com"
    },
    "stationInfo":{
       "stationId":2,
       "analyzer":"ffffff",
       "analyzerv2":"gggggg",
       "location":"bbbsr",
       "installDt":"2020-09-02",
       "token":"ddffgdhtgsaerre",
       "macNo":"ytggvdctrf",
       "stationNo":"45678765",
       "stnType":"dfrgth",
       "hasThresold":"23456",
       "stationVendor":"cccccc",
       "latitude":"45",
       "longitute":"87",
       "measurementPrinciple":"fgdhgh",
       "stackHeight":"yujhgfd",
       "stackDiameter":"rfgttt",
       "stackVelocity":"tgrrgfrdgv",
       "gasDischargeRate":"rrr",
       "remarks":"wwwwwwwwwwww",
       "parameterInfo":[
          {
             "paramter":"er4eftggg",
             "analyserMake":"fff",
             "analyserModel":"vvvv",
             "analyserSerialNo":"gggg",
             "devidceIMEINo":"hhhh",
             "macId":"yyyyy",
             "measurmentRange":"iiii",
             "Unit":"iiii"
          },
          {
             "paramter":"ppppppppppppppp",
             "analyserMake":"ffedrf",
             "analyserModel":"vvvffddv",
             "analyserSerialNo":"ggsssgg",
             "devidceIMEINo":"hhssahh",
             "macId":"yyyaassyy",
             "measurmentRange":"iissddii",
             "Unit":"erf"
          }
       ]
    }
 }

  
];
add_industry:FormGroup;

plant =new PlantInfoData();

cleardata:FormGroup;

 submitted = false;
 ind_gen_name:string="";
 ind_gen_ddlcategory:string="Select";
      ind_gen_vender:string="";
      ind_gen_existing_part_id:string="";
      ind_gen__district:string="Select";
      ind_reg_ofc:string="";
      ind_gen_caaqme:string="";
      ind_gen_cemc:string="";
      ind_gen_no_of_cemes:string="";
      ind_gen_prim_cont_pername:string="";
      ind_gen_prim_design:string="";
      ind_gen_prim_phone:string="";
      ind_gen_prim_email:string="";
      ind_gen_security_cont_person_name:string="";
      ind_gen_security_cont_degn:string="";
      ind_gen_security_cont_phone:string="";
      ind_gen_security_cont_email:string="";
      ind_gen_address:string="";
      ind_gen_address_Town:string="";
      ind_gen_address_District:string="";
      ind_gen_address_State:string="";
      ind_gen_address_Pincode:string="";

      ind_network_conn_data_trans:string="";
      ind_network_con_historical_data_activity:string="";

     ind_network_con_station_name:string="";
     ind_network_con_monitoring_typ:string="";


     title1:string="";
     title2: string="";
     Password:string="";


    
    ind_network_con_process_attached: string="";
    ind_network_con_vendor:string="";
    ind_network_con_analyser_make: string="";
    ind_network_con_analyser_model:string="";
    ind_network_con_analyser_serial_number:string="";
    ind_network_con_device_imei_number:string="";
    ind_network_con_mac_id: string="";
    ind_network_con_measurement_range_min: string="";
     ind_network_con_measurement_range_max:string="";
    ind_network_con_parameter: string="";
    ind_network_con_unit: string="";
    ind_network_con_certification: string="";
    ind_network_con_longitude: string="";
    ind_network_con_latitude: string="";
    ind_network_con_measurement_principle: string="";
    ind_network_con_stack_height: string="";
    ind_network_con_stack_diameter:string="";
    ind_network_con_stack_velocity: string="";
    ind_network_con_flue_gas_discharge_rate_m3_hr: string="";
   ind_network_con_remark:string="";

     



  constructor(private route:Router,private register:UserService,private formBuilder: FormBuilder,private HttpClient:HttpClient) {
   
   }


      
  ngOnInit():void {
    //start

  //  alert(this.plant);
  
  

   //end

  
 localStorage.setItem('length' ,String(0)); 

this.containers.length=Number(localStorage.getItem('length'));
this.add();



     this.add_industry = this.formBuilder.group({
      
      Password: ['', [Validators.required,CustomValidators.patternValidator(/\d/, { hasNumber: true }),CustomValidators.patternValidator(/[A-Z]/, { hasCapitalCase: true }), CustomValidators.patternValidator(/[a-z]/, { hasSmallCase: true }),Validators.minLength(8)]],
    


			ind_gen_name: ['', [Validators.required]],
      ind_gen_ddlcategory: ['', [Validators.required]],
      ind_gen_vender: ['', [Validators.required]],
      ind_gen_existing_part_id: ['', [Validators.required]],
      ind_gen__district: ['', [Validators.required]],
      ind_reg_ofc: ['', [Validators.required]],
      ind_gen_caaqme: ['', [Validators.required]],
      ind_gen_cemc: ['', [Validators.required]],
      ind_gen_no_of_cemes: ['', [Validators.required]],
      ind_gen_prim_cont_pername: ['', [Validators.required]],
      ind_gen_prim_design: ['', [Validators.required]],
      ind_gen_prim_phone: ['', [Validators.required,Validators.minLength(10),CustomValidators.patternValidator(/\d/, { hasNumber: true })]],
      ind_gen_prim_email: ['', [Validators.required,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      ind_gen_security_cont_person_name: ['', [Validators.required]],
      ind_gen_security_cont_degn: ['', [Validators.required]],
      ind_gen_security_cont_phone:['', [Validators.required,Validators.minLength(10),CustomValidators.patternValidator(/\d/, { hasNumber: true })]],
      ind_gen_security_cont_email: ['', [Validators.required,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],  
      ind_gen_address: ['', [Validators.required]],
      ind_gen_address_Town: ['', [Validators.required]],
      ind_gen_address_District: ['', [Validators.required]],
      ind_gen_address_State: ['', [Validators.required]],
      ind_gen_address_Pincode: ['', [Validators.required,Validators.minLength(7),CustomValidators.patternValidator(/\d/, { hasNumber: true })]],

      //*********network connection details******//

      ind_network_conn_data_trans: ['', [Validators.required]],
      ind_network_con_historical_data_activity: ['', [Validators.required]],
      ind_network_con_monitoring_typ: ['', [Validators.required]],
      ind_network_con_station_name: ['', [Validators.required]],
      ind_network_con_process_attached: ['', [Validators.required]],
      ind_network_con_vendor: ['', [Validators.required]],
      ind_network_con_analyser_make: ['', [Validators.required]],
      ind_network_con_analyser_model: ['', [Validators.required]],
      ind_network_con_analyser_serial_number: ['', [Validators.required]],
      ind_network_con_device_imei_number: ['', [Validators.required]],
      ind_network_con_mac_id: ['', [Validators.required]],
      ind_network_con_measurement_range_min: ['', [Validators.required]],
       ind_network_con_measurement_range_max: ['', [Validators.required]],
      ind_network_con_parameter: ['', [Validators.required]],
      ind_network_con_unit: ['', [Validators.required]],
      ind_network_con_certification: ['', [Validators.required]],
      ind_network_con_longitude: ['', [Validators.required]],
      ind_network_con_latitude: ['', [Validators.required]],
      ind_network_con_measurement_principle: ['', [Validators.required]],
      ind_network_con_stack_height: ['', [Validators.required]],
      ind_network_con_stack_diameter: ['', [Validators.required]],
      ind_network_con_stack_velocity: ['', [Validators.required]],
      ind_network_con_flue_gas_discharge_rate_m3_hr: ['', [Validators.required]],
     ind_network_con_remark:['', [Validators.required]]
     
     

		});
  }

clear(input: HTMLInputElement){
 
  input.value = ''; // null should work too, but as the type ov the value is string I like to use ''
}

  OnClick()
  {
  
  }
  add() {
   this.containers.length=Number(localStorage.getItem('length'));  
    this.containers.push(this.containers.length);
   
    localStorage.setItem('length' ,String(this.containers.length+1)); 

    
  }

  


  goback(){
  this.route.navigateByUrl("/regdetails");
}
get f() { return this.add_industry.controls; }

Insert()
{
  
   this.submitted = true;
  if (this.add_industry.invalid) {
   // alert('Please Fillup All Data');
           // return;
        }
        else
        
        {
          
          const register =this.register.insert(this.plant).subscribe(data=>{
            debugger;
          
          
            if(data.apiStatus.message === "success") {
            
            //	window.localStorage.setItem('token', data.result.token);
           
             // this.route.navigate(['/login']);
              alert('Saved Data');
             
              }else {
              //this.invalidLogin = true;
              //alert('data is'+data.data);
              console.log(data);
              }
              
            });

          }
        

}
}
