export class Login {
    username:string="hindalco";
    password:string="hindalco@123";
}
